module.exports = {
  BOT_TOKEN: "8246353367:AAEtB5p2y4lEbPkypGgQbuhT9OpHvd386yQ", //token lu
  OWNER_ID: ["7618047705"], //id lu
};